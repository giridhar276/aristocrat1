


# dictionary
book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(book)
# display individual key-value
print(book["chap1"])

book["chap4"] = 40
print(book)

print(list(book.keys()))
print(list(book.values()))
print(book.items())


if "chap6" in book:
    print(book["chap6"])
    
    
    
print(book.get("chap6"))    


# book is getting updated for newbook
newbook = {"chap8":80,"chap9":90}
book.update(newbook)
print(book)

## If any object is prefixed with ** , it becomes dictionary
## 2nd approach
output = {**book, **newbook}
print(output)







