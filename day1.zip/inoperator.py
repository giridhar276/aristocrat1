


name = "python programming"
if "python" in name:
    print("existing")
    

alist = [10,20,30,40]

getcount = alist.count(10)
if getcount> 0 :
    print("10 exists")
    
## 2nd approach
if 10 in alist:
    print("exists")
    


adict = {"chap1":10 , "chap2":20}
if "chap1" in adict:
    print("key exists")
