



val = 10

print(type(val))

if isinstance(val, int ):
    print("True")
else:
    print("False")
    

if isinstance(val, list ):
    print("True")
else:
    print("False")
    
    
alist = [10,20]
if isinstance(alist,list):
    print("Its the list")
else:
    print("not list")





