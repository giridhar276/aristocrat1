



name ="python programming"


print(name)  # zython programming

aname = 'unix'
bname = "unix shell scripting"

print(name,aname,bname)
### string[start:stop:step]
print(name);
print(name[0]);  # p
print(name[1]) ; # y
print(name[0:4]) #pyth
print(name[3:6]) #
print(name[3:6:1]) #
print(name[2:])
print(name[:5])
print(name[:])   # everything
print(name[::])
print(name[0:17:2])
print(name[1:17:2])
print(name[-1])
print(name[-2])
print(name[-4:-2])
print(name[::-1])
print(name[-2:-4:-1])




first = "python"
second = "programming"

output = first + " " + second
print(output)


first = [10,20]
second = [30,40]
output = first + second
print(output)


first = (10,20)
second = (50,60)
output = first + second
print(output)








