

name ="python programming"

print(name.capitalize())
print(name.lower())
print(name.upper())
print(name.swapcase())

print(name.center(50))
print(name.center(50,"*"))
print(name)
print(name.replace("python", "ruby"))
print(name)
print(name.isupper())
print(name.islower())
print(name.split(" "))
output = name.split(" ")
print(output)

aname = " python   "
print(len(aname))
bname = aname.strip()  # remove whitespace at both ends
print(len(bname))

query = "I love {0} and {1}"
print(query.format("python","scala"))
print(query.format(1, 2))


query = "I love {1} and {0}"
print(query.format("python","scala"))
print(query.format(1, 2))

print(name.encode(encoding='utf-32'))




a,b = 10,20

if a < b :
    print("Inside if cond")
    print("Still inside if")
else:
    print("inside else cond")
    print("Still inside else")

#######################################
name = "python"
if name.islower():
    print("string is lower")
else:
    print("string is upper")
    
    

name = "python"
if name.islower():
    print("String is lower")
elif name.isupper():
    print("String is upper")



name = "java programming"
if len(name) > 10 :
    print("some logic")    
    
    
    



















