



z = "192.168.0."
for x in range(1,11):
    print(z+str(x))
