



print("python programming")


print("scala programming")


print(10,20,30,40)

print("unix","perl")

print([10,20,30],(45,67))

