
atup = (10,20,30,40)
print("Tuple elements are", atup)
atup[0] = 1000
print("After replacing:", atup)

atup.

atup = (10,20,30,40)
# converting to list
alist = list(atup)
alist.append(50)
alist[0] = 1000
# recoverting back to tuple
atup = tuple(alist)
print(atup)

atup.count(10)