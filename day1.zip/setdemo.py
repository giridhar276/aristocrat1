



aset = {10,10,10,20,30,30,30}
bset = {30,30,40,40,50}
cset = {20,30,40,50,60}
print(aset)
print(bset)


print(aset.union(bset))
print(aset.intersection(bset).intersection(cset))
print(aset.difference(bset))
print(bset.difference(aset))
print(aset.issubset(bset))


alist = [10,10,20,30,40,50]
aset = set(alist)
print(aset)



for val in aset:
    print(val)
    
    

