

network = {
    "type": "DeviceConfiguration",
    "general": {
        "hostname": "DeviceNameExample",
        "timezone": "Europe/Amsterdam",
        "maintainer": "email@example.org",
        "description": "general info here",
        "ula_prefix": "fd8e:f40a:6701::/48"
    },
    "hardware": {
        "model": "Example model",
        "manufacturer": "Example inc.",
        "version": 1,
        "cpu": "Atheros AR2317"
    },
    "operating_system": {
        "name": "OpenWRT",
        "description": "OpenWrt Barrier Breaker 14.07",
        "version": "Barrier Breaker",
        "revision": "r43321",
        "kernel": "3.10.49"
    }
}