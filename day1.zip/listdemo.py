
alist = [10,20,30,40,50,56,2,4,65,6]

print(alist[0:3])
print(alist[::-1])
print(alist[::2])

# append() : one object will be added at the end of the list
alist.append(900)
print("After appending:",alist)
alist.append(90)
print("After appending:",alist)

# extend() : adding an iterable

alist.extend([34,23,12])
print("After extending:", alist)
alist.extend([34])
print("After extending:", alist)

# list.insert(where to insert , what to insert)
alist.insert(0,100)
print("After inserting:", alist)

alist.pop()   # last value will be removed
print("After pop", alist)

alist.pop(0)
print("After pop", alist)
returnedvalue = alist.pop(4)
print("After pop", alist)
print(returnedvalue)

getcount = alist.count(10)
print(getcount)



if 400 in alist:
    alist.remove(400)
    print("After removing:",alist)
    
    
alist.reverse()
print("After reversing:", alist)


alist.sort()
print("After sorting:",alist)







