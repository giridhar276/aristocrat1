
for val in range(1,11):
    print(val)
    
for val in range(1,11,2):
    print(val)    
    

## for with string
name ="python"
for char in name[0::2]:
    print(char)
    
## for with list
alist = [10,20,30]
for val in alist:
    print(val)
    
## for with tuple
atup = ("unix","linux","perl")
for item in atup:
    print(item)
    
    
## for with dictionary
## read only KEY and displaying key,value both
book = {"chap1":10 ,"chap2":20}
for key in book.keys():
    print(key)
    print(book[key])
    
# we are key,value both
for key,value in book.items():
    print(key,value)    
    

for value in book.values():
    print(value)
    



    