

#1st approach to open the file
fobj = open("info.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()


# context manager
# if the line starts with the keyword 'with' it is called as context manager
# file will be closed automatically when it moves out of context/indentation
with open("infonew.txt","w") as fobj:
    fobj.write("unix shell scripting\n")
    fobj.write("java programming")



# if the file has to be created in different path ....
fobj = open("D:\\trainings\\info.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")

fobj.close()