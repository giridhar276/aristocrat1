




def display(first,*data):
    print(first)
    print(data)
    

display(10)