# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 12:02:25 2021

@author: gsripath
"""

def display(second,first):
    print(first)
    print(second)




display(first=10,second=20)