from openpyxl.workbook import Workbook
wb = Workbook()

ws1 = wb.create_sheet("Sheet_A")
ws1.title = "Title_A"

ws2 = wb.create_sheet("Sheet_B")
ws2.title = "Title_B"

wb.save(filename = 'sample_book.xlsx')
