import pymysql
import csv

try:
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='aristocrat')
    #print(db)
    #step2 : create cursor
    cursor = db.cursor()   
    with open("realestate.csv","r") as fobj:
        reader = csv.reader(fobj)
        for line in reader:   
            query = "insert into aristocrat.realestate values('{}','{}')".format(line[0],line[1])               
            #step3: execute the query
            cursor.execute(query)  
    db.commit()
    #step5 : close the connection

    
    db.close()
except pymysql.OperationalError as err:
    print("Invalid Input")
except pymysql.IntegrityError as err:
    print(err)
except (pymysql.DatabaseError,pymysql.ProgrammingError) as err:
    print(err)
except TypeError as err:
    print(err)
except Exception as err:
    print(err)
