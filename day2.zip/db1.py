
#step1: establish the connection
#step2: prepare query
#step3: executing query
#step4: fetch the output
#step5  close the connection

import pymysql

try:
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='aristocrat')
    #print(db)
    #step2 : create cursor
    cursor = db.cursor()   
    query = "select * from realestate"   
    #step3: execute the query
    cursor.execute(query)
    
    #step4 : fetch the output
    for record in cursor.fetchall():
        print("Street:",record[0])
        print("City  :",record[1])
        print("--------")
        
    #step5 : close the connection
    db.close()
except pymysql.OperationalError as err:
    print("Invalid credentials")
except pymysql.IntegrityError as err:
    print(err)
except (pymysql.DatabaseError,pymysql.ProgrammingError) as err:
    print(err)
except TypeError as err:
    print(err)
except Exception as err:
    print(err)



