


# importe required libraries 
import openpyxl 
import csv 

  
# open given workbook  
# and store in excel object  
excel = openpyxl.load_workbook("19_Feb_2021.xlsx") 
  
# select the active sheet 
sheet = excel.active 
  
# writer object is created 
col = csv.writer(open("realestate_new.csv", 'w',  newline="")) 
  
# writing the data in csv file 
for r in sheet.rows: 
    # row by row write  
    # operation is perform 
    col.writerow([cell.value for cell in r]) 
  