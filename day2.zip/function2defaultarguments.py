



## function overloading in python
# default arguments

def display(a=0,b=0,c=0,d=0):
    print(a,b,c,d)
    

display()
display(10)
display(10,20)
display(10,20,30)
display(10,20,30,40)

print(list(range(10)))
print(list(range(1,10)))
print(list(range(1,10,2)))

print(1,2,sep="\n")
print("first line",end="\n\n",sep="  ")
print("second line")

print("first line",sep="  ",end="\n\n")
print("second line")









