

import csv
import sys
try:
    with open("realestate1111.csv","r") as fobj:
        csvreader = csv.reader(fobj)
        for line in csvreader:
            print(line[0])
            print(line[1])
            print("-------")

except FileNotFoundError as err:
    print("Error : File not found")
    print("system generated error:",err)
except IndexError as error:
    print("system generated error:",error)
except (ValueError,ZeroDivisionError) as err:
    print(err)
except Exception as err:
    print("system generated error:",err)  
    print(sys.exc_info())
    