


import csv
with open("realestate.csv") as fobj:
    csvreader = csv.reader(fobj)
    for line in csvreader:
        print(line[0])
        print(line[1])
        print("-------")