
## reading the file line by line
# fobj acts as file object or file handler or cursor
with open("languages.txt") as fobj:
    for line in fobj:
        # remove whitespaces if any
        line = line.strip()
        output = line.split(":")
        print(output[0])



## using readlines()
with open("languages.txt") as fobj:
    print(fobj.readlines())


## using readlines()
with open("languages.txt") as fobj:
    print(fobj.read())
    
    
import csv
with open("languages.csv") as fobj:
    #converting file object to csv object
    csvreader = csv.reader(fobj,delimiter=':')
    #print(csv.reader(fobj,delimiter=':'))
    for line in csvreader:
        print(line)
        

        
        
        