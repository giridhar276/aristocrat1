# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 17:01:12 2021

@author: gsripath
"""


import requests
import bs4
from bs4 import BeautifulSoup


response = requests.get("https://www.techworldguru.com/python-assignment-2/")

if response.status_code== 200 :
    
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
        
    #print(soup.get_text())