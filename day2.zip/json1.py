


import json

with open('employee.json') as fobj:
    # convert into json object
    data = json.load(fobj)
    for key,value in data.items():
        if isinstance(value,list):
            for item in value:

                for skey,svalue in item.items():
                    print(skey.ljust(15),svalue)
    
    
