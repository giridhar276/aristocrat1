import csv
cityset = set()
with open("realestate.csv") as fobj:
    header = fobj.readline()
    csvreader = csv.reader(fobj)
    ## processing
    for line in csvreader:
        city = line[1]
        cityset.add(city)
    ## displaying

    for city in cityset:
        print(city)

import csv
citylist = list()
with open("realestate.csv") as fobj:
    csvreader = csv.reader(fobj)
    ## processing
    for line in csvreader:
        city = line[1]
        citylist.append(city)
    ## displaying
    
    sortlist = list(set(citylist))
    sortlist.sort()
    print(sortlist)
    for city in set(citylist):
        print(city)


import csv
citylist = list()
with open("realestate.csv") as fobj:
    csvreader = csv.reader(fobj)
    ## processing
    for line in csvreader:
        city = line[1]
        if city not in citylist:
            citylist.append(city)
    ## displaying
    for city in citylist:
        print(city)
