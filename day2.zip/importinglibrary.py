


import os
filesize = os.path.getsize(filename)


## 1st approach
import math
print(math.floor(3.4))
print(math.ceil(3.4))


## 2nd approach
import math as m
print(m.log(2))
print(m.tan(2))


## 3rd approach
from math import floor,tan,log,sin
print(floor(3.4))


##4rd approach
from math import *
print(floor(3.4))
print(log(3))