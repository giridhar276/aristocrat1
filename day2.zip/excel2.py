import pymysql
from openpyxl import Workbook
import time

wb = Workbook()

# grab the active worksheet
ws = wb.active
filename = time.strftime("%d_%b_%Y.xlsx")
try:
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='aristocrat')
    #print(db)
    #step2 : create cursor
    cursor = db.cursor()   
    query = "select * from realestate"   
    #step3: execute the query
    cursor.execute(query)
    
    #step4 : fetch the output
    for record in cursor.fetchall():
        ws.append(record)
        #print(record)

        
    #step5 : close the connection
    db.close()
    wb.save(filename)
    
    
except pymysql.OperationalError as err:
    print("Invalid credentials")
except pymysql.IntegrityError as err:
    print(err)
except (pymysql.DatabaseError,pymysql.ProgrammingError) as err:
    print(err)
except TypeError as err:
    print(err)
except Exception as err:
    print(err)

