




import datetime

print(datetime.datetime.now())

print(datetime.date.today())

import time
print(time.time())