


import csv
import sys

try:
    with open("realestate.csv","r") as fobj:
        with open("backup.csv","w") as fwrite:
            csvreader = csv.reader(fobj)
            for line in csvreader:
                if 'SACRAMENTO' in line:
                    line[1] = "BANGALORE"
                newline = ",".join(line)
                fwrite.write(newline+"\n")

except Exception as err:
    print(err)
