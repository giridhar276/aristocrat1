




def add(val):
    return val + 5

total = add(10)
print(total)
# syntax
#functioname = lambda variables : expression
# lambda is the replacement of single liner function


add = lambda x : x + 5

total = add(10)
print(total)


upper = lambda x : x.upper()

name = "python"
getupper = upper(name)
print(getupper)



alist = ["google","oracle","microsoft"]

for line in alist:
    string = "http://www." + line + ".com"
    print(string)
    
import sys








# 2nd approach
alist = ["google","oracle","microsoft"]
def append(string):
    return "http://www." + string + ".com"

print(list(map(append,alist)))


# 3rd  approach
alist = ["google","oracle","microsoft"]
print(list(map(lambda x :"http://www." + x + ".com" ,alist)))


alist = [1,2,3,4,5,6]
print(list(filter(lambda x:x%2, alist)))



alist = ["google","unix","linux","oracle"]
print(list(filter(lambda x:len(x)==6, alist)))






 


        
        
        









